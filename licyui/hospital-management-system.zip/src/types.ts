export type PatientCondition = 'Stable' | 'Critical' | 'Observation' | 'Post-Op' | 'Discharging';

export interface Vitals {
  bp: string; // e.g. "120/80 mmHg"
  hr: number; // bpm
  spo2: number; // %
  temp: number; // Celsius e.g. 37.1
  rr: number; // breaths/min
  painScore: number; // 0-10
}

export interface Patient {
  id: string;
  mrn: string; // Medical Record Number
  name: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  bloodGroup: string;
  room: string;
  bed: string;
  department: 'Cardiology' | 'Intensive Care (ICU)' | 'Emergency (ED)' | 'General Medicine' | 'Oncology' | 'Pediatrics' | 'Surgery';
  admissionDate: string;
  attendingDoctor: string;
  diagnosis: string;
  condition: PatientCondition;
  vitals: Vitals;
  allergies: string[];
  activeMedications: string[];
  medicalHistory: string[];
  notes?: string;
  avatarSeed?: string;
}

export interface Medication {
  id: string;
  barcode: string;
  ndc: string; // National Drug Code
  name: string;
  genericName: string;
  category: 'Antibiotic' | 'Cardiovascular' | 'Analgesic' | 'Anticoagulant' | 'Antidiabetic' | 'Respiratory' | 'Emergency / Resuscitation' | 'Gastrointestinal';
  strength: string;
  form: 'Tablet' | 'Capsule' | 'IV Injection' | 'Syrup' | 'Inhaler' | 'Subcutaneous Injection' | 'Ointment';
  route: 'Oral' | 'Intravenous (IV)' | 'Subcutaneous (SC)' | 'Inhalation' | 'Intramuscular (IM)' | 'Topical';
  stockQuantity: number;
  minThreshold: number;
  unit: string;
  expirationDate: string;
  batchNumber: string;
  isHighAlert: boolean;
  manufacturer: string;
  storageCondition: string;
  description: string;
  contraindications: string[];
  typicalAdultDosage: string;
}

export interface EMAROrder {
  id: string;
  patientId: string;
  medicationId: string;
  medicationName: string;
  dosage: string;
  route: string;
  frequency: string;
  scheduledTime: string;
  status: 'Scheduled' | 'Administered' | 'Delayed' | 'Contraindicated' | 'Discontinued';
  administeredAt?: string;
  administeredBy?: string;
  verifiedBarcode?: string;
  notes?: string;
  isHighAlert?: boolean;
}

export interface FiveRightsCheck {
  rightPatient: boolean;
  rightDrug: boolean;
  rightDose: boolean;
  rightRoute: boolean;
  rightTime: boolean;
}

export interface MedicationScanResult {
  id: string;
  timestamp: string;
  inputType: 'camera' | 'upload' | 'barcode' | 'preset';
  targetPatientId?: string;
  imageThumbnail?: string;
  identification: {
    brandName: string;
    genericName: string;
    strength: string;
    dosageForm: string;
    route: string;
    lotOrBatch: string;
    expirationDate: string;
    ndcOrBarcode: string;
    isHighAlert: boolean;
    confidenceScore: number;
  };
  safetyAnalysis: {
    status: 'SAFE' | 'WARNING' | 'CRITICAL_ALERT';
    allergyConflict: boolean;
    allergyDetails: string | null;
    interactionDetected: boolean;
    interactionSeverity: 'None' | 'Mild' | 'Moderate' | 'Severe';
    interactionDetails: string | null;
    dosageEvaluation: string;
    recommendation: 'SAFE_TO_ADMINISTER' | 'WARNING_REVIEW_REQUIRED' | 'CRITICAL_CONTRAINDICATION_HOLD';
    summaryExplanation: string;
    nursingPrecautions: string[];
    fiveRights: FiveRightsCheck;
  };
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'agent' | 'system';
  content: string;
  timestamp: string;
  citations?: string[];
  tags?: string[];
}

export type ClinicianRole = 
  | 'Attending Physician' 
  | 'Charge Nurse' 
  | 'Clinical Pharmacist' 
  | 'Hospital Administrator';

export interface ClinicianUser {
  id: string;
  badgeNumber: string;
  name: string;
  role: ClinicianRole;
  department: string;
  licenseNumber: string;
  station: string;
  shift: string;
  avatarInitials: string;
  pin: string;
}
