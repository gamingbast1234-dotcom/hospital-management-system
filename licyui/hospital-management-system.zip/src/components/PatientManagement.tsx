import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Plus, 
  Scan, 
  Bot, 
  AlertTriangle, 
  Heart, 
  Activity, 
  FileText, 
  Clock, 
  X, 
  Pill,
  CheckCircle2,
  Calendar,
  UserCheck
} from 'lucide-react';
import { Patient, Medication } from '../types';

interface PatientManagementProps {
  patients: Patient[];
  medications: Medication[];
  onOpenScanner: (patientId: string) => void;
  onConsultAI: (prompt: string) => void;
  onAddPatient: (newPatient: Patient) => void;
  selectedPatientId?: string;
}

export const PatientManagement: React.FC<PatientManagementProps> = ({
  patients,
  medications,
  onOpenScanner,
  onConsultAI,
  onAddPatient,
  selectedPatientId: initialSelectedId,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [conditionFilter, setConditionFilter] = useState<string>('all');
  const [activePatientModal, setActivePatientModal] = useState<Patient | null>(
    initialSelectedId ? patients.find(p => p.id === initialSelectedId) || null : null
  );
  const [isAdmitModalOpen, setIsAdmitModalOpen] = useState(false);

  // New patient form state
  const [newPatientForm, setNewPatientForm] = useState({
    name: '',
    age: 50,
    gender: 'Male' as const,
    bloodGroup: 'O+',
    room: 'Room 310',
    bed: 'Bed A',
    department: 'General Medicine' as const,
    attendingDoctor: 'Dr. Sarah Jenkins, MD',
    diagnosis: '',
    condition: 'Stable' as const,
    allergies: '',
    activeMedications: '',
    notes: '',
  });

  const filteredPatients = patients.filter(p => {
    const matchesSearch = 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.mrn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.diagnosis.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.room.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDept = departmentFilter === 'all' || p.department === departmentFilter;
    const matchesCondition = conditionFilter === 'all' || p.condition === conditionFilter;
    return matchesSearch && matchesDept && matchesCondition;
  });

  const handleAdmitSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPatientForm.name || !newPatientForm.diagnosis) return;

    const newPat: Patient = {
      id: `pat-${Date.now()}`,
      mrn: `MRN-${Math.floor(100000 + Math.random() * 900000)}`,
      name: newPatientForm.name,
      age: Number(newPatientForm.age),
      gender: newPatientForm.gender,
      bloodGroup: newPatientForm.bloodGroup,
      room: newPatientForm.room,
      bed: newPatientForm.bed,
      department: newPatientForm.department as any,
      admissionDate: new Date().toISOString().split('T')[0],
      attendingDoctor: newPatientForm.attendingDoctor,
      diagnosis: newPatientForm.diagnosis,
      condition: newPatientForm.condition,
      vitals: {
        bp: '120/80 mmHg',
        hr: 75,
        spo2: 98,
        temp: 36.9,
        rr: 16,
        painScore: 2,
      },
      allergies: newPatientForm.allergies
        ? newPatientForm.allergies.split(',').map(s => s.trim())
        : ['No Known Drug Allergies (NKDA)'],
      activeMedications: newPatientForm.activeMedications
        ? newPatientForm.activeMedications.split(',').map(s => s.trim())
        : [],
      medicalHistory: ['Admitted today.'],
      notes: newPatientForm.notes,
    };

    onAddPatient(newPat);
    setIsAdmitModalOpen(false);
    setActivePatientModal(newPat);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header & Filters */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <Users className="h-5 w-5 text-teal-400" />
            <span>Inpatient Directory & Clinical Charts</span>
          </h2>
          <p className="text-xs text-slate-400">Electronic health record summaries with integrated barcode medication scanning</p>
        </div>

        <button
          onClick={() => setIsAdmitModalOpen(true)}
          className="flex items-center space-x-2 px-4 py-2 bg-teal-500 hover:bg-teal-600 text-white text-xs sm:text-sm font-semibold rounded-xl transition shadow"
        >
          <Plus className="h-4 w-4" />
          <span>Admit New Patient</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2 flex-1 min-w-[240px]">
          <Search className="h-4 w-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Filter by name, MRN, room, or diagnosis..."
            className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-1.5 focus:outline-none focus:border-teal-400 placeholder-slate-400"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={departmentFilter}
            onChange={(e) => setDepartmentFilter(e.target.value)}
            className="bg-slate-800 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-teal-400"
          >
            <option value="all">All Departments</option>
            <option value="Cardiology">Cardiology</option>
            <option value="Intensive Care (ICU)">ICU</option>
            <option value="Emergency (ED)">Emergency (ED)</option>
            <option value="General Medicine">General Medicine</option>
            <option value="Surgery">Surgery</option>
          </select>

          <select
            value={conditionFilter}
            onChange={(e) => setConditionFilter(e.target.value)}
            className="bg-slate-800 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-teal-400"
          >
            <option value="all">All Acuity Conditions</option>
            <option value="Critical">Critical</option>
            <option value="Stable">Stable</option>
            <option value="Observation">Observation</option>
            <option value="Post-Op">Post-Op</option>
          </select>
        </div>
      </div>

      {/* Patient Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredPatients.map((patient) => {
          const isCrit = patient.condition === 'Critical';
          const hasAllergy = patient.allergies.length > 0 && patient.allergies[0] !== 'No Known Drug Allergies (NKDA)';

          return (
            <div
              key={patient.id}
              className={`p-4 rounded-xl border flex flex-col justify-between transition cursor-pointer hover:border-teal-500/50 ${
                isCrit ? 'bg-rose-950/20 border-rose-800/40' : 'bg-slate-900 border-slate-800 hover:bg-slate-850'
              }`}
              onClick={() => setActivePatientModal(patient)}
            >
              <div>
                {/* Header: Room, Bed & Condition */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="px-2 py-0.5 text-xs font-mono font-bold bg-slate-800 text-teal-300 border border-slate-700 rounded">
                      {patient.room} • {patient.bed}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">[{patient.mrn}]</span>
                  </div>

                  <span className={`px-2 py-0.5 text-[10px] font-bold rounded ${
                    patient.condition === 'Critical' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' :
                    patient.condition === 'Observation' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' :
                    patient.condition === 'Post-Op' ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40' :
                    'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  }`}>
                    {patient.condition}
                  </span>
                </div>

                {/* Patient Identity & Diagnosis */}
                <div className="mt-2.5">
                  <h3 className="font-bold text-white text-base">{patient.name}</h3>
                  <p className="text-xs text-slate-400">
                    {patient.age} years • {patient.gender} • Blood: <span className="font-mono text-slate-300">{patient.bloodGroup}</span>
                  </p>
                  <p className="text-xs text-slate-300 mt-1 line-clamp-2">
                    <strong className="text-teal-400">{patient.department}:</strong> {patient.diagnosis}
                  </p>
                </div>

                {/* Allergy Badge */}
                {hasAllergy ? (
                  <div className="mt-3 p-1.5 bg-rose-500/10 border border-rose-500/30 rounded-lg text-[11px] font-medium text-rose-300 flex items-center space-x-1.5">
                    <AlertTriangle className="h-3 w-3 shrink-0" />
                    <span className="truncate">Allergy: {patient.allergies.join(', ')}</span>
                  </div>
                ) : (
                  <div className="mt-3 text-[11px] text-emerald-400 flex items-center space-x-1">
                    <CheckCircle2 className="h-3 w-3" />
                    <span>NKDA (No known allergies)</span>
                  </div>
                )}

                {/* Vitals Snapshot */}
                <div className="mt-3 grid grid-cols-3 gap-1.5 text-[11px] bg-slate-800/80 p-2 rounded-lg text-slate-300 font-mono">
                  <div>BP: <strong className="text-white">{patient.vitals.bp}</strong></div>
                  <div>HR: <strong className="text-white">{patient.vitals.hr}</strong></div>
                  <div>SpO2: <strong className={patient.vitals.spo2 < 95 ? 'text-rose-400' : 'text-white'}>{patient.vitals.spo2}%</strong></div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenScanner(patient.id);
                  }}
                  className="flex-1 py-1.5 bg-teal-500/20 hover:bg-teal-500/30 text-teal-300 border border-teal-500/40 rounded-lg text-xs font-semibold flex items-center justify-center space-x-1 transition"
                >
                  <Scan className="h-3.5 w-3.5" />
                  <span>Scan Medication</span>
                </button>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onConsultAI(`Review patient chart for ${patient.name} (${patient.mrn}), diagnosed with ${patient.diagnosis}. Evaluate current medications (${patient.activeMedications.join(', ')}) and allergies (${patient.allergies.join(', ')}).`);
                  }}
                  className="p-1.5 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-lg border border-slate-700 hover:text-white transition"
                  title="Ask AI Agent about this patient"
                >
                  <Bot className="h-4 w-4 text-teal-400" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Patient Detail Chart Modal */}
      {activePatientModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="px-6 py-4 bg-slate-850 border-b border-slate-700 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="h-10 w-10 rounded-xl bg-teal-500/20 border border-teal-500/30 flex items-center justify-center text-teal-400 font-bold">
                  {activePatientModal.name.charAt(0)}
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h3 className="text-lg font-bold text-white">{activePatientModal.name}</h3>
                    <span className="font-mono text-xs px-2 py-0.5 bg-slate-800 text-slate-300 rounded border border-slate-700">
                      {activePatientModal.mrn}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    {activePatientModal.room} • {activePatientModal.bed} • {activePatientModal.department} • Attending: {activePatientModal.attendingDoctor}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActivePatientModal(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-6 overflow-y-auto">
              {/* Vitals Monitor Bar */}
              <div className="p-4 bg-slate-850 rounded-xl border border-slate-750">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center space-x-1.5">
                  <Activity className="h-4 w-4 text-teal-400" />
                  <span>Real-Time Bedside Vitals</span>
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-6 gap-3 text-center">
                  <div className="p-2 bg-slate-800 rounded-lg">
                    <span className="text-[10px] text-slate-400 block">Blood Pressure</span>
                    <span className="text-sm font-bold text-white font-mono">{activePatientModal.vitals.bp}</span>
                  </div>
                  <div className="p-2 bg-slate-800 rounded-lg">
                    <span className="text-[10px] text-slate-400 block">Heart Rate</span>
                    <span className="text-sm font-bold text-teal-400 font-mono">{activePatientModal.vitals.hr} bpm</span>
                  </div>
                  <div className="p-2 bg-slate-800 rounded-lg">
                    <span className="text-[10px] text-slate-400 block">SpO2 Oxygen</span>
                    <span className={`text-sm font-bold font-mono ${activePatientModal.vitals.spo2 < 95 ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {activePatientModal.vitals.spo2}%
                    </span>
                  </div>
                  <div className="p-2 bg-slate-800 rounded-lg">
                    <span className="text-[10px] text-slate-400 block">Temperature</span>
                    <span className="text-sm font-bold text-white font-mono">{activePatientModal.vitals.temp}°C</span>
                  </div>
                  <div className="p-2 bg-slate-800 rounded-lg">
                    <span className="text-[10px] text-slate-400 block">Respirations</span>
                    <span className="text-sm font-bold text-white font-mono">{activePatientModal.vitals.rr} /min</span>
                  </div>
                  <div className="p-2 bg-slate-800 rounded-lg">
                    <span className="text-[10px] text-slate-400 block">Pain Score</span>
                    <span className="text-sm font-bold text-amber-400 font-mono">{activePatientModal.vitals.painScore} / 10</span>
                  </div>
                </div>
              </div>

              {/* Allergies & Safety Warnings */}
              <div className="p-4 bg-slate-850 rounded-xl border border-slate-750">
                <h4 className="text-xs font-bold uppercase tracking-wider text-rose-400 mb-2 flex items-center space-x-1.5">
                  <AlertTriangle className="h-4 w-4 text-rose-400" />
                  <span>Documented Allergies & Sensitivities</span>
                </h4>
                <div className="flex flex-wrap gap-2">
                  {activePatientModal.allergies.map((allergy, i) => (
                    <span
                      key={i}
                      className={`px-3 py-1 rounded-lg text-xs font-semibold ${
                        allergy.includes('NKDA') 
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' 
                          : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                      }`}
                    >
                      {allergy}
                    </span>
                  ))}
                </div>
                {activePatientModal.notes && (
                  <p className="text-xs text-slate-300 mt-2 bg-slate-800/80 p-2.5 rounded-lg border border-slate-700">
                    <strong>Clinical Note:</strong> {activePatientModal.notes}
                  </p>
                )}
              </div>

              {/* Active Medications List */}
              <div className="p-4 bg-slate-850 rounded-xl border border-slate-750">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
                    <Pill className="h-4 w-4 text-teal-400" />
                    <span>Active Inpatient Medication Orders</span>
                  </h4>
                  <button
                    onClick={() => {
                      onOpenScanner(activePatientModal.id);
                      setActivePatientModal(null);
                    }}
                    className="px-3 py-1 bg-teal-500 hover:bg-teal-600 text-white rounded-lg text-xs font-bold flex items-center space-x-1 transition shadow"
                  >
                    <Scan className="h-3.5 w-3.5" />
                    <span>Scan Bedside Medication</span>
                  </button>
                </div>

                <div className="space-y-2">
                  {activePatientModal.activeMedications.map((medStr, idx) => (
                    <div key={idx} className="p-3 bg-slate-800 rounded-lg border border-slate-700 flex items-center justify-between text-xs">
                      <div className="flex items-center space-x-2">
                        <Pill className="h-4 w-4 text-teal-400 shrink-0" />
                        <span className="font-semibold text-white">{medStr}</span>
                      </div>
                      <button
                        onClick={() => {
                          onOpenScanner(activePatientModal.id);
                          setActivePatientModal(null);
                        }}
                        className="text-teal-400 hover:text-teal-300 font-semibold"
                      >
                        Verify with Scanner &rarr;
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-4 bg-slate-850 border-t border-slate-800 flex items-center justify-between">
              <button
                onClick={() => {
                  onConsultAI(`Generate an updated SBAR handoff report and discharge medication reconciliation for patient ${activePatientModal.name} (MRN: ${activePatientModal.mrn}, Diagnosis: ${activePatientModal.diagnosis}).`);
                  setActivePatientModal(null);
                }}
                className="flex items-center space-x-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-750 text-teal-300 border border-slate-700 rounded-xl text-xs font-semibold"
              >
                <Bot className="h-4 w-4" />
                <span>Generate SBAR with AI</span>
              </button>

              <button
                onClick={() => {
                  onOpenScanner(activePatientModal.id);
                  setActivePatientModal(null);
                }}
                className="flex items-center space-x-2 px-5 py-2 bg-teal-500 hover:bg-teal-600 text-white rounded-xl text-xs font-bold shadow"
              >
                <Scan className="h-4 w-4" />
                <span>Open Medication Scanner</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admit New Patient Modal */}
      {isAdmitModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <UserCheck className="h-5 w-5 text-teal-400" />
                <span>Admit New Inpatient to HMS</span>
              </h3>
              <button onClick={() => setIsAdmitModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleAdmitSubmit} className="space-y-4 mt-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-medium block mb-1">Patient Full Name</label>
                  <input
                    type="text"
                    required
                    value={newPatientForm.name}
                    onChange={(e) => setNewPatientForm({ ...newPatientForm, name: e.target.value })}
                    placeholder="e.g. Margaret Thatcher"
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-medium block mb-1">Age & Gender</label>
                  <div className="flex space-x-2">
                    <input
                      type="number"
                      required
                      value={newPatientForm.age}
                      onChange={(e) => setNewPatientForm({ ...newPatientForm, age: Number(e.target.value) })}
                      className="w-20 bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                    />
                    <select
                      value={newPatientForm.gender}
                      onChange={(e) => setNewPatientForm({ ...newPatientForm, gender: e.target.value as any })}
                      className="flex-1 bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-medium block mb-1">Department</label>
                  <select
                    value={newPatientForm.department}
                    onChange={(e) => setNewPatientForm({ ...newPatientForm, department: e.target.value as any })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                  >
                    <option value="Cardiology">Cardiology</option>
                    <option value="Intensive Care (ICU)">ICU</option>
                    <option value="Emergency (ED)">Emergency (ED)</option>
                    <option value="General Medicine">General Medicine</option>
                    <option value="Surgery">Surgery</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-300 font-medium block mb-1">Room & Bed</label>
                  <div className="flex space-x-2">
                    <input
                      type="text"
                      value={newPatientForm.room}
                      onChange={(e) => setNewPatientForm({ ...newPatientForm, room: e.target.value })}
                      placeholder="Room 310"
                      className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-medium block mb-1">Primary Diagnosis</label>
                <input
                  type="text"
                  required
                  value={newPatientForm.diagnosis}
                  onChange={(e) => setNewPatientForm({ ...newPatientForm, diagnosis: e.target.value })}
                  placeholder="e.g. Acute Coronary Syndrome, Hypertension"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-300 font-medium block mb-1">Known Drug Allergies (comma separated)</label>
                <input
                  type="text"
                  value={newPatientForm.allergies}
                  onChange={(e) => setNewPatientForm({ ...newPatientForm, allergies: e.target.value })}
                  placeholder="e.g. Penicillin, Aspirin, Sulfa drugs (or leave blank for NKDA)"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-300 font-medium block mb-1">Active Prescribed Medications</label>
                <input
                  type="text"
                  value={newPatientForm.activeMedications}
                  onChange={(e) => setNewPatientForm({ ...newPatientForm, activeMedications: e.target.value })}
                  placeholder="e.g. Lisinopril 10mg, Metformin 850mg"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAdmitModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-500 hover:bg-teal-600 text-white font-bold rounded-lg shadow"
                >
                  Confirm Admission
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
