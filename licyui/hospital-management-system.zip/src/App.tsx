import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { DashboardOverview } from './components/DashboardOverview';
import { PatientManagement } from './components/PatientManagement';
import { MedicationInventory } from './components/MedicationInventory';
import { EMARSchedule } from './components/EMARSchedule';
import { MedicationScannerModal } from './components/MedicationScannerModal';
import { AIAgentDrawer } from './components/AIAgentDrawer';
import { LoginPage } from './components/LoginPage';
import { 
  INITIAL_PATIENTS, 
  INITIAL_MEDICATIONS, 
  INITIAL_EMAR_ORDERS,
  DEFAULT_CLINICAL_API_KEY,
  CLINICIAN_STAFF_PRESETS
} from './data/hospitalData';
import { Patient, Medication, EMAROrder, MedicationScanResult, ClinicianUser } from './types';
import { CheckCircle2, ShieldAlert, X } from 'lucide-react';

export default function App() {
  // Authentication & Clinician Station State
  const [currentUser, setCurrentUser] = useState<ClinicianUser | null>(() => {
    const saved = localStorage.getItem('aegis_active_clinician');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return null;
      }
    }
    return null; // Show login page initially so user sees the login page immediately
  });

  const [currentApiKey, setCurrentApiKey] = useState<string>(() => {
    return localStorage.getItem('aegis_custom_gemini_key') || DEFAULT_CLINICAL_API_KEY;
  });

  const [activeTab, setActiveTab] = useState<'dashboard' | 'patients' | 'scanner' | 'medications' | 'emar'>('dashboard');
  const [patients, setPatients] = useState<Patient[]>(INITIAL_PATIENTS);
  const [medications, setMedications] = useState<Medication[]>(INITIAL_MEDICATIONS);
  const [emarOrders, setEmarOrders] = useState<EMAROrder[]>(INITIAL_EMAR_ORDERS);

  // Modals and Drawer state
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [scannerTargetPatientId, setScannerTargetPatientId] = useState<string | undefined>(undefined);
  const [isAIAgentOpen, setIsAIAgentOpen] = useState(false);
  const [aiAgentPrompt, setAiAgentPrompt] = useState<string | undefined>(undefined);
  const [selectedPatientId, setSelectedPatientId] = useState<string | undefined>(undefined);
  const [searchQuery, setSearchQuery] = useState('');

  // Toast notification
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'warning'; text: string } | null>(null);

  // Sync API Key with server on mount
  useEffect(() => {
    fetch('/api/auth/api-key-status')
      .then(res => res.json())
      .then(data => {
        if (data.apiKey) {
          setCurrentApiKey(data.apiKey);
        }
      })
      .catch(() => {});
  }, []);

  const handleUpdateApiKey = async (newKey: string): Promise<boolean> => {
    try {
      const res = await fetch('/api/auth/set-api-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiKey: newKey }),
      });
      const data = await res.json();
      if (data.success) {
        setCurrentApiKey(newKey);
        localStorage.setItem('aegis_custom_gemini_key', newKey);
        showToast('success', 'Gemini AI Clinical Gateway key updated and active.');
        return true;
      }
    } catch (err) {
      console.warn('Could not update key on server, persisting locally:', err);
    }
    setCurrentApiKey(newKey);
    localStorage.setItem('aegis_custom_gemini_key', newKey);
    return true;
  };

  const showToast = (type: 'success' | 'warning', text: string) => {
    setToastMessage({ type, text });
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  const handleLogin = (user: ClinicianUser) => {
    setCurrentUser(user);
    showToast('success', `Welcome, ${user.name} (${user.role}). Workstation authenticated.`);
  };

  const handleLogout = () => {
    localStorage.removeItem('aegis_active_clinician');
    setCurrentUser(null);
    showToast('warning', 'Workstation session locked. Clinical access suspended.');
  };

  const handleOpenScanner = (patientId?: string, barcode?: string) => {
    setScannerTargetPatientId(patientId);
    setIsScannerOpen(true);
  };

  const handleOpenAIAgent = (prompt?: string) => {
    setAiAgentPrompt(prompt);
    setIsAIAgentOpen(true);
  };

  const handleAdministerMedication = (result: MedicationScanResult) => {
    const patient = patients.find(p => p.id === result.targetPatientId);
    const medName = result.identification.brandName;

    // Decrement inventory stock
    setMedications(prev => prev.map(m => {
      if (m.barcode === result.identification.ndcOrBarcode || m.name.toLowerCase().includes(result.identification.genericName.toLowerCase())) {
        return {
          ...m,
          stockQuantity: Math.max(0, m.stockQuantity - 1)
        };
      }
      return m;
    }));

    // Update or add eMAR Order
    const newEmarItem: EMAROrder = {
      id: `emar-adm-${Date.now()}`,
      patientId: result.targetPatientId || patients[0].id,
      medicationId: result.identification.ndcOrBarcode,
      medicationName: `${result.identification.brandName} (${result.identification.genericName})`,
      dosage: result.identification.strength,
      route: result.identification.route,
      frequency: 'Stat / Scheduled',
      scheduledTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'Administered',
      administeredAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      administeredBy: currentUser ? `${currentUser.name} (${currentUser.role})` : 'Nurse Clara Oswald, RN',
      verifiedBarcode: result.identification.ndcOrBarcode,
      notes: `Verified via AI Barcode BCMA Scanner. Five-Rights confirmed by ${currentUser?.name || 'Staff'}.`,
      isHighAlert: result.identification.isHighAlert,
    };

    setEmarOrders(prev => [newEmarItem, ...prev]);

    showToast('success', `Verified & Administered: ${medName} for ${patient?.name || 'patient'}. eMAR updated & pharmacy stock decremented.`);
  };

  const handleAddPatient = (newPat: Patient) => {
    setPatients(prev => [newPat, ...prev]);
    showToast('success', `Inpatient ${newPat.name} admitted to ${newPat.department} (${newPat.room}).`);
  };

  const handleAddMedication = (newMed: Medication) => {
    setMedications(prev => [newMed, ...prev]);
    showToast('success', `New medication ${newMed.name} added to hospital formulary.`);
  };

  const criticalAlertCount = emarOrders.filter(o => o.status === 'Contraindicated').length;

  // If clinician has not signed in, show the dedicated Hospital Login Page
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-teal-500 selection:text-white">
        {toastMessage && (
          <div className="fixed top-6 right-6 z-50 animate-bounce">
            <div className={`p-4 rounded-xl shadow-2xl border flex items-center space-x-3 text-xs sm:text-sm font-semibold ${
              toastMessage.type === 'success'
                ? 'bg-emerald-950 border-emerald-500 text-emerald-200'
                : 'bg-rose-950 border-rose-500 text-rose-200'
            }`}>
              {toastMessage.type === 'success' ? (
                <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0" />
              ) : (
                <ShieldAlert className="h-5 w-5 text-rose-400 shrink-0" />
              )}
              <span>{toastMessage.text}</span>
              <button onClick={() => setToastMessage(null)} className="ml-2 text-slate-400 hover:text-white">
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}

        <LoginPage
          onLogin={handleLogin}
          currentApiKey={currentApiKey}
          onUpdateApiKey={handleUpdateApiKey}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-teal-500 selection:text-white">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 animate-bounce">
          <div className={`p-4 rounded-xl shadow-2xl border flex items-center space-x-3 text-xs sm:text-sm font-semibold ${
            toastMessage.type === 'success'
              ? 'bg-emerald-950 border-emerald-500 text-emerald-200'
              : 'bg-rose-950 border-rose-500 text-rose-200'
          }`}>
            {toastMessage.type === 'success' ? (
              <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0" />
            ) : (
              <ShieldAlert className="h-5 w-5 text-rose-400 shrink-0" />
            )}
            <span>{toastMessage.text}</span>
            <button onClick={() => setToastMessage(null)} className="ml-2 text-slate-400 hover:text-white">
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        openScanner={() => handleOpenScanner()}
        toggleAIAgent={() => setIsAIAgentOpen(!isAIAgentOpen)}
        isAIAgentOpen={isAIAgentOpen}
        criticalAlertCount={criticalAlertCount}
        onNewPatient={() => setActiveTab('patients')}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        currentUser={currentUser}
        onLogout={handleLogout}
        onOpenLogin={() => setCurrentUser(null)}
        currentApiKey={currentApiKey}
      />

      {/* Primary Main Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {activeTab === 'dashboard' && (
          <DashboardOverview
            patients={patients}
            medications={medications}
            emarOrders={emarOrders}
            onOpenScanner={handleOpenScanner}
            onOpenAIAgent={handleOpenAIAgent}
            onSelectPatient={(pId) => {
              setSelectedPatientId(pId);
              setActiveTab('patients');
            }}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'patients' && (
          <PatientManagement
            patients={patients}
            medications={medications}
            onOpenScanner={handleOpenScanner}
            onConsultAI={handleOpenAIAgent}
            onAddPatient={handleAddPatient}
            selectedPatientId={selectedPatientId}
          />
        )}

        {activeTab === 'scanner' && (
          <div className="py-6 space-y-6">
            <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl text-center max-w-2xl mx-auto space-y-4">
              <div className="h-16 w-16 bg-teal-500/20 text-teal-400 border border-teal-500/30 rounded-2xl flex items-center justify-center mx-auto">
                <ShieldAlert className="h-8 w-8 animate-pulse" />
              </div>
              <h2 className="text-xl font-bold text-white">Full Medication & Barcode Scanner Console</h2>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                Scan patient wristbands and medication barcodes, or photograph pills and blister packs with AI vision to enforce Five-Rights verification and prevent adverse drug events.
              </p>
              <button
                onClick={() => handleOpenScanner()}
                className="px-6 py-3 bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-600 hover:to-emerald-700 text-white font-bold rounded-xl shadow-lg transition"
              >
                Open Bedside Scanner Modal
              </button>
            </div>
          </div>
        )}

        {activeTab === 'medications' && (
          <MedicationInventory
            medications={medications}
            onOpenScannerWithBarcode={(barcode) => {
              handleOpenScanner(undefined, barcode);
            }}
            onConsultAI={handleOpenAIAgent}
            onAddMedication={handleAddMedication}
          />
        )}

        {activeTab === 'emar' && (
          <EMARSchedule
            emarOrders={emarOrders}
            patients={patients}
            medications={medications}
            onOpenScanner={handleOpenScanner}
            onConsultAI={handleOpenAIAgent}
          />
        )}
      </main>

      {/* Medication Scanner Modal */}
      <MedicationScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        patients={patients}
        medications={medications}
        selectedPatientId={scannerTargetPatientId}
        onAdministerMedication={handleAdministerMedication}
        onConsultAI={handleOpenAIAgent}
      />

      {/* AI Clinical Agent Drawer */}
      <AIAgentDrawer
        isOpen={isAIAgentOpen}
        onClose={() => setIsAIAgentOpen(false)}
        patients={patients}
        medications={medications}
        initialPrompt={aiAgentPrompt}
        onOpenScannerForPatient={handleOpenScanner}
      />
    </div>
  );
}
