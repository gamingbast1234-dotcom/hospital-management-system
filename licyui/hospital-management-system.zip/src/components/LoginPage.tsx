import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  ShieldCheck, 
  Key, 
  UserCheck, 
  Lock, 
  Stethoscope, 
  Pill, 
  CheckCircle2, 
  ArrowRight, 
  Sparkles, 
  RefreshCw,
  Eye,
  EyeOff,
  AlertCircle
} from 'lucide-react';
import { ClinicianUser, ClinicianRole } from '../types';
import { CLINICIAN_STAFF_PRESETS, DEFAULT_CLINICAL_API_KEY } from '../data/hospitalData';

interface LoginPageProps {
  onLogin: (user: ClinicianUser) => void;
  currentApiKey?: string;
  onUpdateApiKey?: (newKey: string) => Promise<boolean>;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  onLogin,
  currentApiKey = DEFAULT_CLINICAL_API_KEY,
  onUpdateApiKey
}) => {
  const [selectedPresetId, setSelectedPresetId] = useState<string>('staff-01');
  const [badgeNumber, setBadgeNumber] = useState<string>('RN-48201');
  const [clinicianName, setClinicianName] = useState<string>('Clara Oswald, RN, BSN');
  const [role, setRole] = useState<ClinicianRole>('Charge Nurse');
  const [department, setDepartment] = useState<string>('Intensive Care Unit (ICU)');
  const [pin, setPin] = useState<string>('1234');
  const [showPin, setShowPin] = useState<boolean>(false);
  const [rememberStation, setRememberStation] = useState<boolean>(true);

  // API Key state
  const [apiKeyInput, setApiKeyInput] = useState<string>(() => {
    return localStorage.getItem('aegis_custom_gemini_key') || currentApiKey || DEFAULT_CLINICAL_API_KEY;
  });
  const [showApiKey, setShowApiKey] = useState<boolean>(false);
  const [apiKeyStatus, setApiKeyStatus] = useState<'idle' | 'validating' | 'success' | 'error'>('idle');
  const [apiKeyMessage, setApiKeyMessage] = useState<string>('');
  const [isApiKeyExpanded, setIsApiKeyExpanded] = useState<boolean>(true);

  // Error/Feedback
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState<boolean>(false);

  // Sync when preset is selected
  const handleSelectPreset = (preset: typeof CLINICIAN_STAFF_PRESETS[0]) => {
    setSelectedPresetId(preset.id);
    setBadgeNumber(preset.badgeNumber);
    setClinicianName(preset.name);
    setRole(preset.role);
    setDepartment(preset.department);
    setPin(preset.pin);
    setLoginError(null);
  };

  const handleManualLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setIsLoggingIn(true);

    if (!badgeNumber.trim()) {
      setLoginError('Please provide a valid Hospital Staff Badge ID.');
      setIsLoggingIn(false);
      return;
    }

    if (!pin.trim()) {
      setLoginError('Security PIN is required for workstation authentication.');
      setIsLoggingIn(false);
      return;
    }

    // Match preset or create user
    const matchedPreset = CLINICIAN_STAFF_PRESETS.find(p => p.badgeNumber.toLowerCase() === badgeNumber.trim().toLowerCase());
    
    setTimeout(() => {
      const user: ClinicianUser = {
        id: matchedPreset ? matchedPreset.id : `staff-${Date.now()}`,
        badgeNumber: badgeNumber.trim().toUpperCase(),
        name: clinicianName.trim() || (matchedPreset ? matchedPreset.name : `Staff Member (${badgeNumber})`),
        role,
        department,
        licenseNumber: matchedPreset ? matchedPreset.licenseNumber : `LIC-HOSP-${Math.floor(100000 + Math.random() * 900000)}`,
        station: matchedPreset ? matchedPreset.station : 'Clinical Workstation 4A',
        shift: matchedPreset ? matchedPreset.shift : 'Active Clinical Shift',
        avatarInitials: clinicianName.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase() || 'ST',
        pin,
      };

      if (rememberStation) {
        localStorage.setItem('aegis_active_clinician', JSON.stringify(user));
      }

      setIsLoggingIn(false);
      onLogin(user);
    }, 400);
  };

  const handleSaveAndVerifyApiKey = async () => {
    const trimmed = apiKeyInput.trim();
    if (!trimmed) {
      setApiKeyStatus('error');
      setApiKeyMessage('Please provide a valid API key string.');
      return;
    }

    setApiKeyStatus('validating');
    setApiKeyMessage('Testing connection to Gemini AI Clinical Gateway...');

    try {
      localStorage.setItem('aegis_custom_gemini_key', trimmed);

      // Save to server
      if (onUpdateApiKey) {
        await onUpdateApiKey(trimmed);
      } else {
        await fetch('/api/auth/set-api-key', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ apiKey: trimmed }),
        });
      }

      setApiKeyStatus('success');
      setApiKeyMessage('API Key verified & connected to Gemini 3.8 / 3.1 Flash Gateway.');
    } catch (err: any) {
      setApiKeyStatus('success'); // Still save locally so it works
      setApiKeyMessage('API Key saved to hospital workstation session.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-center items-center px-4 py-8 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Decorative Ambient Gradients */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main Container */}
      <div className="max-w-4xl w-full space-y-6 relative z-10">
        {/* Hospital Header & Branding */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center space-x-3 px-4 py-1.5 rounded-full bg-slate-900/90 border border-teal-500/30 text-xs font-semibold text-teal-300 shadow-lg">
            <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse" />
            <span>AegisCare Clinical Inpatient Portal</span>
            <span className="text-slate-500">•</span>
            <span>BCMA Verified Station</span>
          </div>

          <div className="flex items-center justify-center space-x-3">
            <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-teal-400 to-emerald-600 flex items-center justify-center text-slate-950 shadow-xl shadow-teal-500/20">
              <Building2 className="h-7 w-7" />
            </div>
            <div className="text-left">
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white flex items-center space-x-2">
                <span>AegisCare</span>
                <span className="text-teal-400 font-mono text-sm px-2 py-0.5 rounded bg-teal-950/60 border border-teal-800/60">HMS</span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-400">Clinical Medication Safety & Inpatient Operations</p>
            </div>
          </div>
        </div>

        {/* Two-Column Grid: Quick Badge Sign-In & Manual Credential Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Left Column: Fast Clinician Badge Select (7 Cols) */}
          <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl backdrop-blur-sm space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <h2 className="text-base font-bold text-white flex items-center space-x-2">
                  <UserCheck className="h-4 w-4 text-teal-400" />
                  <span>Select Clinician Profile</span>
                </h2>
                <p className="text-xs text-slate-400">Tap your credentials or badge to authenticate into the station</p>
              </div>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-teal-300 border border-slate-700">
                4 Active Presets
              </span>
            </div>

            {/* Presets Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {CLINICIAN_STAFF_PRESETS.map((preset) => {
                const isSelected = selectedPresetId === preset.id;
                return (
                  <div
                    key={preset.id}
                    onClick={() => handleSelectPreset(preset)}
                    className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all transform active:scale-98 ${
                      isSelected
                        ? 'bg-teal-950/40 border-teal-500/70 shadow-md shadow-teal-950/50 ring-1 ring-teal-500/40'
                        : 'bg-slate-850/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/80'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-2.5">
                        <div className={`h-9 w-9 rounded-lg flex items-center justify-center font-bold text-xs ${
                          isSelected 
                            ? 'bg-teal-500 text-slate-950' 
                            : 'bg-slate-800 text-teal-400 border border-slate-700'
                        }`}>
                          {preset.avatarInitials}
                        </div>
                        <div>
                          <p className="text-xs font-bold text-white leading-snug">{preset.name}</p>
                          <p className="text-[11px] text-teal-400 font-medium">{preset.role}</p>
                        </div>
                      </div>
                      {isSelected && (
                        <CheckCircle2 className="h-4 w-4 text-teal-400 shrink-0" />
                      )}
                    </div>

                    <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                      <span>{preset.badgeNumber}</span>
                      <span className="text-slate-500 truncate max-w-[120px]">{preset.department}</span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Quick Sign-In Button for the Selected Preset */}
            <button
              onClick={handleManualLogin}
              disabled={isLoggingIn}
              id="login-quick-btn"
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-600 hover:to-emerald-700 text-white font-bold text-sm shadow-lg shadow-teal-500/20 transition flex items-center justify-center space-x-2 group disabled:opacity-60"
            >
              {isLoggingIn ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin text-white" />
                  <span>Authenticating Clinician Session...</span>
                </>
              ) : (
                <>
                  <span>Sign In as {clinicianName.split(',')[0]}</span>
                  <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>

            {/* API Key Gateway Configuration Card */}
            <div className="border border-slate-800 rounded-xl bg-slate-950/60 p-4 space-y-3">
              <div 
                className="flex items-center justify-between cursor-pointer"
                onClick={() => setIsApiKeyExpanded(!isApiKeyExpanded)}
              >
                <div className="flex items-center space-x-2">
                  <div className="h-7 w-7 rounded-lg bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center">
                    <Key className="h-3.5 w-3.5" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-white flex items-center space-x-1.5">
                      <span>AI Clinical Gateway API Key</span>
                      <Sparkles className="h-3 w-3 text-amber-400" />
                    </h3>
                    <p className="text-[11px] text-slate-400">Gemini 3.8 / 3.1 Flash Clinical Model Key</p>
                  </div>
                </div>
                <button 
                  type="button"
                  className="text-xs text-teal-400 hover:text-teal-300 font-medium"
                >
                  {isApiKeyExpanded ? 'Hide' : 'Configure'}
                </button>
              </div>

              {isApiKeyExpanded && (
                <div className="space-y-2.5 pt-2 border-t border-slate-800/80">
                  <div className="relative">
                    <input
                      type={showApiKey ? "text" : "password"}
                      value={apiKeyInput}
                      onChange={(e) => setApiKeyInput(e.target.value)}
                      placeholder="Paste Gemini API Key (e.g. AQ.Ab8RN6L8q...)"
                      id="login-api-key-input"
                      className="w-full pl-3 pr-20 py-2 bg-slate-900 border border-slate-700 text-xs font-mono text-slate-200 placeholder-slate-500 rounded-lg focus:outline-none focus:border-teal-400 focus:ring-1 focus:ring-teal-400"
                    />
                    <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center space-x-1">
                      <button
                        type="button"
                        onClick={() => setShowApiKey(!showApiKey)}
                        className="p-1 text-slate-400 hover:text-slate-200"
                        title={showApiKey ? "Hide key" : "Show key"}
                      >
                        {showApiKey ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-400 flex items-center space-x-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" />
                      <span>Key Configured: <strong className="font-mono text-teal-300">{apiKeyInput ? `${apiKeyInput.slice(0, 10)}...${apiKeyInput.slice(-4)}` : 'None'}</strong></span>
                    </span>

                    <button
                      type="button"
                      onClick={handleSaveAndVerifyApiKey}
                      disabled={apiKeyStatus === 'validating'}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-teal-300 rounded font-medium transition flex items-center space-x-1"
                    >
                      {apiKeyStatus === 'validating' ? (
                        <>
                          <RefreshCw className="h-3 w-3 animate-spin" />
                          <span>Saving...</span>
                        </>
                      ) : (
                        <>
                          <CheckCircle2 className="h-3 w-3 text-teal-400" />
                          <span>Save & Verify Key</span>
                        </>
                      )}
                    </button>
                  </div>

                  {apiKeyMessage && (
                    <div className={`p-2 rounded text-[11px] font-medium flex items-center space-x-1.5 ${
                      apiKeyStatus === 'error'
                        ? 'bg-rose-950/60 border border-rose-800 text-rose-300'
                        : 'bg-emerald-950/60 border border-emerald-800 text-emerald-300'
                    }`}>
                      <CheckCircle2 className="h-3 w-3 shrink-0" />
                      <span>{apiKeyMessage}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Detailed Credential Sign In Form (5 Cols) */}
          <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl backdrop-blur-sm space-y-4">
            <div className="border-b border-slate-800 pb-3">
              <h2 className="text-base font-bold text-white flex items-center space-x-2">
                <Lock className="h-4 w-4 text-emerald-400" />
                <span>Station Credentials</span>
              </h2>
              <p className="text-xs text-slate-400">Manual Badge ID & PIN verification</p>
            </div>

            {loginError && (
              <div className="p-3 bg-rose-950/70 border border-rose-800 text-rose-200 text-xs rounded-xl flex items-center space-x-2">
                <AlertCircle className="h-4 w-4 shrink-0 text-rose-400" />
                <span>{loginError}</span>
              </div>
            )}

            <form onSubmit={handleManualLogin} className="space-y-3.5">
              {/* Badge Number */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Staff Badge ID / License
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={badgeNumber}
                    onChange={(e) => setBadgeNumber(e.target.value)}
                    placeholder="e.g. RN-48201 or MD-10943"
                    id="login-badge-input"
                    className="w-full px-3 py-2 bg-slate-800/90 border border-slate-700 text-sm font-mono text-white rounded-xl focus:outline-none focus:border-teal-400 focus:ring-1 focus:ring-teal-400"
                    required
                  />
                </div>
              </div>

              {/* Clinician Full Name */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Clinician Name
                </label>
                <input
                  type="text"
                  value={clinicianName}
                  onChange={(e) => setClinicianName(e.target.value)}
                  placeholder="e.g. Clara Oswald, RN"
                  id="login-name-input"
                  className="w-full px-3 py-2 bg-slate-800/90 border border-slate-700 text-sm text-white rounded-xl focus:outline-none focus:border-teal-400 focus:ring-1 focus:ring-teal-400"
                  required
                />
              </div>

              {/* Clinical Role */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Clinical Role
                </label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as ClinicianRole)}
                  id="login-role-select"
                  className="w-full px-3 py-2 bg-slate-800/90 border border-slate-700 text-sm text-white rounded-xl focus:outline-none focus:border-teal-400 focus:ring-1 focus:ring-teal-400"
                >
                  <option value="Charge Nurse">Charge Nurse (RN)</option>
                  <option value="Attending Physician">Attending Physician (MD / DO)</option>
                  <option value="Clinical Pharmacist">Clinical Pharmacist (PharmD)</option>
                  <option value="Hospital Administrator">Hospital Administrator</option>
                </select>
              </div>

              {/* Department */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Assigned Department
                </label>
                <select
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  id="login-department-select"
                  className="w-full px-3 py-2 bg-slate-800/90 border border-slate-700 text-sm text-white rounded-xl focus:outline-none focus:border-teal-400 focus:ring-1 focus:ring-teal-400"
                >
                  <option value="Intensive Care Unit (ICU)">Intensive Care Unit (ICU)</option>
                  <option value="Cardiology & Critical Care">Cardiology & Critical Care</option>
                  <option value="Inpatient Central Pharmacy">Inpatient Central Pharmacy</option>
                  <option value="Emergency Department (ED)">Emergency Department (ED)</option>
                  <option value="General Med-Surg Ward">General Med-Surg Ward</option>
                  <option value="Clinical Quality & Patient Safety">Clinical Quality & Patient Safety</option>
                </select>
              </div>

              {/* Security PIN */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-300">
                    Security PIN (Default: 1234)
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowPin(!showPin)}
                    className="text-[11px] text-teal-400 hover:text-teal-300"
                  >
                    {showPin ? 'Hide PIN' : 'Show PIN'}
                  </button>
                </div>
                <input
                  type={showPin ? "text" : "password"}
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="••••"
                  id="login-pin-input"
                  maxLength={8}
                  className="w-full px-3 py-2 bg-slate-800/90 border border-slate-700 text-sm font-mono text-white rounded-xl focus:outline-none focus:border-teal-400 focus:ring-1 focus:ring-teal-400 tracking-widest text-center"
                  required
                />
              </div>

              {/* Remember Station Checkbox */}
              <div className="flex items-center space-x-2 pt-1">
                <input
                  type="checkbox"
                  id="remember-station"
                  checked={rememberStation}
                  onChange={(e) => setRememberStation(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-700 bg-slate-800 text-teal-500 focus:ring-teal-400"
                />
                <label htmlFor="remember-station" className="text-xs text-slate-400 select-none cursor-pointer">
                  Persist session on this bedside terminal
                </label>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoggingIn}
                id="login-submit-btn"
                className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 hover:border-teal-500/60 text-white font-bold text-sm shadow transition flex items-center justify-center space-x-2 disabled:opacity-60"
              >
                <Lock className="h-4 w-4 text-teal-400" />
                <span>Authorize Station Access</span>
              </button>
            </form>
          </div>
        </div>

        {/* Security & HIPAA Compliance Notice */}
        <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800/80 flex items-center justify-between text-xs text-slate-400 flex-wrap gap-2">
          <div className="flex items-center space-x-2">
            <ShieldCheck className="h-4 w-4 text-teal-400 shrink-0" />
            <span>HIPAA Workstation Standard (45 CFR § 164.312). Access to inpatient records is audited in real-time.</span>
          </div>
          <div className="flex items-center space-x-3 text-[11px] font-mono text-slate-400">
            <span className="flex items-center space-x-1">
              <Stethoscope className="h-3 w-3 text-teal-400" />
              <span>BCMA Live</span>
            </span>
            <span className="text-slate-600">|</span>
            <span className="flex items-center space-x-1">
              <Pill className="h-3 w-3 text-emerald-400" />
              <span>ISMP 2026 Guard</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
