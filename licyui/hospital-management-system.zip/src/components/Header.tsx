import React, { useState } from 'react';
import { 
  Building2, 
  Scan, 
  Bot, 
  Bell, 
  Search, 
  Activity, 
  ShieldAlert, 
  Plus,
  LogOut,
  Key,
  ShieldCheck
} from 'lucide-react';
import { ClinicianUser } from '../types';

interface HeaderProps {
  activeTab: 'dashboard' | 'patients' | 'scanner' | 'medications' | 'emar';
  setActiveTab: (tab: 'dashboard' | 'patients' | 'scanner' | 'medications' | 'emar') => void;
  openScanner: () => void;
  toggleAIAgent: () => void;
  isAIAgentOpen: boolean;
  criticalAlertCount: number;
  onNewPatient: () => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  currentUser: ClinicianUser | null;
  onLogout: () => void;
  onOpenLogin: () => void;
  currentApiKey?: string;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  openScanner,
  toggleAIAgent,
  isAIAgentOpen,
  criticalAlertCount,
  onNewPatient,
  searchQuery,
  setSearchQuery,
  currentUser,
  onLogout,
  onOpenLogin,
  currentApiKey,
}) => {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  return (
    <header className="sticky top-0 z-40 bg-slate-900 text-white border-b border-slate-800 shadow-md">
      {/* Top Banner with System Indicators */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Hospital Logo & Brand */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
              <div className="h-10 w-10 rounded-xl bg-teal-500/20 border border-teal-500/40 flex items-center justify-center text-teal-400">
                <Building2 className="h-6 w-6" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-lg font-bold tracking-tight text-white">AegisCare</span>
                  <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-teal-500/20 text-teal-300 border border-teal-500/30 rounded">HMS</span>
                </div>
                <p className="text-xs text-slate-400">Clinical & Medication Management</p>
              </div>
            </div>

            {/* Live Clinical Badge */}
            <div className="hidden lg:flex items-center space-x-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700/60 text-xs text-slate-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>BCMA Live Active</span>
              <span className="text-slate-500">|</span>
              <span className="font-mono text-slate-400">Station 4A</span>
            </div>
          </div>

          {/* Search Bar */}
          <div className="hidden md:flex flex-1 max-w-md mx-6">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search patient MRN, name, or medication barcode..."
                className="w-full pl-9 pr-4 py-1.5 bg-slate-800/90 border border-slate-700 text-sm text-slate-200 placeholder-slate-400 rounded-lg focus:outline-none focus:border-teal-400 focus:ring-1 focus:ring-teal-400 transition"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Primary Action: Medication Scanner Button */}
            <button
              onClick={openScanner}
              id="header-scan-btn"
              className="flex items-center space-x-2 px-3.5 py-2 bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-600 hover:to-emerald-700 text-white text-xs sm:text-sm font-semibold rounded-lg shadow-sm shadow-teal-500/30 transition transform active:scale-95"
            >
              <Scan className="h-4 w-4 animate-pulse" />
              <span className="whitespace-nowrap">Scan Medication</span>
            </button>

            {/* AI Agent Toggle */}
            <button
              onClick={toggleAIAgent}
              id="header-ai-agent-btn"
              className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-medium border transition ${
                isAIAgentOpen 
                  ? 'bg-teal-500/20 text-teal-300 border-teal-500/50 shadow-inner' 
                  : 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-750 hover:text-white'
              }`}
            >
              <Bot className="h-4 w-4 text-teal-400" />
              <span className="hidden sm:inline">AI Clinical Agent</span>
            </button>

            {/* Quick Admit Patient */}
            <button
              onClick={onNewPatient}
              id="header-admit-btn"
              title="Admit New Inpatient"
              className="p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white rounded-lg transition"
            >
              <Plus className="h-4 w-4" />
            </button>

            {/* Critical Alert Indicator */}
            <div className="relative">
              <button 
                onClick={() => setActiveTab('emar')}
                className="p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 rounded-lg relative transition"
                title={`${criticalAlertCount} Active Safety Alerts`}
              >
                <Bell className="h-4 w-4" />
                {criticalAlertCount > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white">
                    {criticalAlertCount}
                  </span>
                )}
              </button>
            </div>

            {/* Clinician Profile & Station Auth Menu */}
            {currentUser ? (
              <div className="relative pl-1 sm:pl-2 border-l border-slate-800 flex items-center space-x-2">
                <button
                  onClick={() => setShowProfileMenu(!showProfileMenu)}
                  id="header-user-profile-btn"
                  className="flex items-center space-x-2 p-1.5 sm:px-2.5 sm:py-1.5 bg-slate-800/90 hover:bg-slate-750 border border-slate-700 rounded-xl transition text-left group"
                >
                  <div className="h-7 w-7 rounded-lg bg-teal-500/20 text-teal-300 border border-teal-500/40 flex items-center justify-center font-bold text-xs">
                    {currentUser.avatarInitials}
                  </div>
                  <div className="hidden xl:block">
                    <p className="text-xs font-bold text-white leading-tight">{currentUser.name.split(',')[0]}</p>
                    <p className="text-[10px] text-teal-400 font-medium leading-none">{currentUser.role}</p>
                  </div>
                </button>

                {/* Quick Lock / Switch Clinician button */}
                <button
                  onClick={onLogout}
                  id="header-logout-btn"
                  title="Lock Workstation / Switch Clinician"
                  className="p-2 bg-slate-800 hover:bg-rose-950/40 hover:text-rose-300 hover:border-rose-800/60 border border-slate-700 text-slate-400 rounded-lg transition"
                >
                  <LogOut className="h-4 w-4" />
                </button>

                {/* Dropdown details */}
                {showProfileMenu && (
                  <div className="absolute right-0 top-12 w-72 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl p-4 z-50 space-y-3">
                    <div className="flex items-start justify-between border-b border-slate-800 pb-3">
                      <div>
                        <p className="text-sm font-bold text-white">{currentUser.name}</p>
                        <p className="text-xs text-teal-400 font-medium">{currentUser.role}</p>
                        <p className="text-[11px] text-slate-400 font-mono mt-0.5">{currentUser.badgeNumber} • {currentUser.department}</p>
                      </div>
                      <span className="px-1.5 py-0.5 text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800 rounded">
                        Active
                      </span>
                    </div>

                    <div className="space-y-1.5 text-xs text-slate-300">
                      <div className="flex justify-between text-slate-400">
                        <span>Workstation:</span>
                        <span className="text-white font-mono">{currentUser.station}</span>
                      </div>
                      <div className="flex justify-between text-slate-400">
                        <span>License:</span>
                        <span className="text-white font-mono">{currentUser.licenseNumber}</span>
                      </div>
                      <div className="flex justify-between text-slate-400">
                        <span>Active Shift:</span>
                        <span className="text-white">{currentUser.shift}</span>
                      </div>
                      <div className="flex justify-between text-slate-400 items-center pt-1 border-t border-slate-800/80">
                        <span className="flex items-center space-x-1">
                          <Key className="h-3 w-3 text-teal-400" />
                          <span>AI Gateway:</span>
                        </span>
                        <span className="text-teal-300 font-mono text-[10px] bg-teal-950/60 px-1.5 py-0.5 rounded border border-teal-800/60">
                          {currentApiKey ? `${currentApiKey.slice(0, 8)}...` : 'Configured'}
                        </span>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-800 flex space-x-2">
                      <button
                        onClick={() => {
                          setShowProfileMenu(false);
                          onOpenLogin();
                        }}
                        className="flex-1 py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 rounded-lg text-center transition"
                      >
                        Switch User / Key
                      </button>
                      <button
                        onClick={() => {
                          setShowProfileMenu(false);
                          onLogout();
                        }}
                        className="py-1.5 px-3 bg-rose-950/60 hover:bg-rose-900 border border-rose-800 text-rose-200 text-xs font-semibold rounded-lg transition flex items-center space-x-1"
                      >
                        <LogOut className="h-3 w-3" />
                        <span>Lock</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={onOpenLogin}
                id="header-signin-btn"
                className="flex items-center space-x-1.5 px-3 py-1.5 bg-teal-500/20 hover:bg-teal-500/30 border border-teal-500/50 text-teal-300 text-xs font-bold rounded-lg transition"
              >
                <ShieldCheck className="h-4 w-4" />
                <span>Clinician Sign In</span>
              </button>
            )}
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 overflow-x-auto py-2 border-t border-slate-800/80 text-sm no-scrollbar">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`px-3.5 py-1.5 rounded-md font-medium text-xs sm:text-sm transition flex items-center space-x-2 whitespace-nowrap ${
              activeTab === 'dashboard'
                ? 'bg-slate-800 text-teal-400 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Activity className="h-4 w-4" />
            <span>Clinical Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab('patients')}
            className={`px-3.5 py-1.5 rounded-md font-medium text-xs sm:text-sm transition flex items-center space-x-2 whitespace-nowrap ${
              activeTab === 'patients'
                ? 'bg-slate-800 text-teal-400 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <span>Inpatients & Beds</span>
          </button>

          <button
            onClick={() => setActiveTab('scanner')}
            className={`px-3.5 py-1.5 rounded-md font-medium text-xs sm:text-sm transition flex items-center space-x-2 whitespace-nowrap ${
              activeTab === 'scanner'
                ? 'bg-slate-800 text-teal-400 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Scan className="h-4 w-4" />
            <span>Medication Scanner (BCMA)</span>
          </button>

          <button
            onClick={() => setActiveTab('emar')}
            className={`px-3.5 py-1.5 rounded-md font-medium text-xs sm:text-sm transition flex items-center space-x-2 whitespace-nowrap ${
              activeTab === 'emar'
                ? 'bg-slate-800 text-teal-400 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <ShieldAlert className="h-4 w-4" />
            <span>eMAR & Scheduled Doses</span>
          </button>

          <button
            onClick={() => setActiveTab('medications')}
            className={`px-3.5 py-1.5 rounded-md font-medium text-xs sm:text-sm transition flex items-center space-x-2 whitespace-nowrap ${
              activeTab === 'medications'
                ? 'bg-slate-800 text-teal-400 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <span>Pharmacy & Formulary</span>
          </button>
        </div>
      </div>
    </header>
  );
};
