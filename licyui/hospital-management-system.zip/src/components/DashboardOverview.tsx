import React from 'react';
import { 
  Users, 
  Bed, 
  Activity, 
  ShieldAlert, 
  Scan, 
  Pill, 
  Bot, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  ArrowUpRight,
  TrendingUp,
  HeartPulse
} from 'lucide-react';
import { Patient, Medication, EMAROrder } from '../types';

interface DashboardOverviewProps {
  patients: Patient[];
  medications: Medication[];
  emarOrders: EMAROrder[];
  onOpenScanner: (patientId?: string) => void;
  onOpenAIAgent: (prompt?: string) => void;
  onSelectPatient: (patientId: string) => void;
  onNavigateTab: (tab: 'dashboard' | 'patients' | 'scanner' | 'medications' | 'emar') => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  patients,
  medications,
  emarOrders,
  onOpenScanner,
  onOpenAIAgent,
  onSelectPatient,
  onNavigateTab,
}) => {
  const totalBeds = 40;
  const occupiedBeds = patients.length;
  const occupancyRate = Math.round((occupiedBeds / totalBeds) * 100);

  const criticalPatients = patients.filter(p => p.condition === 'Critical');
  const administeredDoses = emarOrders.filter(o => o.status === 'Administered');
  const scheduledDoses = emarOrders.filter(o => o.status === 'Scheduled');
  const contraindicatedDoses = emarOrders.filter(o => o.status === 'Contraindicated');

  const lowStockMeds = medications.filter(m => m.stockQuantity <= m.minThreshold);
  const highAlertMeds = medications.filter(m => m.isHighAlert);

  // Department counts
  const departments = [
    { name: 'Cardiology', icon: '❤️', patients: patients.filter(p => p.department === 'Cardiology').length, capacity: 8 },
    { name: 'Intensive Care (ICU)', icon: '⚡', patients: patients.filter(p => p.department === 'Intensive Care (ICU)').length, capacity: 6 },
    { name: 'Emergency (ED)', icon: '🚨', patients: patients.filter(p => p.department === 'Emergency (ED)').length, capacity: 10 },
    { name: 'General Medicine', icon: '🩺', patients: patients.filter(p => p.department === 'General Medicine').length, capacity: 12 },
    { name: 'Surgery', icon: '🩹', patients: patients.filter(p => p.department === 'Surgery').length, capacity: 4 },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Top Clinical Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Bed Occupancy */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Bed Occupancy Census</span>
            <span className="p-2 rounded-lg bg-teal-500/10 text-teal-400">
              <Bed className="h-4 w-4" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-extrabold text-white">{occupiedBeds}</span>
            <span className="text-xs text-slate-400">/ {totalBeds} Beds ({occupancyRate}%)</span>
          </div>
          <div className="mt-2 w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
            <div 
              className="bg-teal-400 h-full rounded-full transition-all" 
              style={{ width: `${occupancyRate}%` }}
            />
          </div>
        </div>

        {/* Metric 2: Today's Verified Administrations */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">BCMA eMAR Doses</span>
            <span className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
              <CheckCircle2 className="h-4 w-4" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-extrabold text-white">{administeredDoses.length}</span>
            <span className="text-xs text-slate-400">of {emarOrders.length} Doses Given</span>
          </div>
          <p className="mt-2 text-[11px] text-emerald-400 flex items-center space-x-1">
            <TrendingUp className="h-3 w-3" />
            <span>100% Five-Rights Scanned</span>
          </p>
        </div>

        {/* Metric 3: Critical Safety Alerts */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Safety & Allergy Holds</span>
            <span className="p-2 rounded-lg bg-rose-500/10 text-rose-400">
              <ShieldAlert className="h-4 w-4" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-extrabold text-rose-400">{contraindicatedDoses.length}</span>
            <span className="text-xs text-slate-400">Active Order Holds</span>
          </div>
          <p className="mt-2 text-[11px] text-rose-300 truncate">
            Penicillin allergy cross-check on Bed 304
          </p>
        </div>

        {/* Metric 4: Pharmacy Formulary & High Alert */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">High-Alert Meds in Use</span>
            <span className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
              <Pill className="h-4 w-4" />
            </span>
          </div>
          <div className="mt-2 flex items-baseline space-x-2">
            <span className="text-2xl font-extrabold text-white">{highAlertMeds.length}</span>
            <span className="text-xs text-slate-400">Active ISMP High-Alert</span>
          </div>
          <p className="mt-2 text-[11px] text-amber-400">
            {lowStockMeds.length > 0 ? `${lowStockMeds.length} items nearing re-order` : 'Formulary levels optimal'}
          </p>
        </div>
      </div>

      {/* Hero Quick Clinical Actions Bar */}
      <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-teal-500/30 rounded-2xl shadow-lg flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="h-12 w-12 rounded-2xl bg-teal-500/20 border border-teal-500/40 flex items-center justify-center text-teal-400 shrink-0">
            <Scan className="h-6 w-6 animate-pulse" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white flex items-center space-x-2">
              <span>Bedside Medication Scanner & Safety System</span>
              <span className="px-2 py-0.5 text-[10px] font-bold bg-teal-500/20 text-teal-300 rounded border border-teal-500/30">BCMA Live</span>
            </h3>
            <p className="text-xs text-slate-400 max-w-xl mt-0.5">
              Scan any medication barcode or photograph pill bottles to verify the 5-Rights, detect allergy conflicts, and prevent drug-drug interactions in real time.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2.5 w-full md:w-auto">
          <button
            onClick={() => onOpenScanner()}
            className="flex-1 md:flex-initial flex items-center justify-center space-x-2 px-5 py-2.5 bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-600 hover:to-emerald-700 text-white text-xs sm:text-sm font-bold rounded-xl shadow-lg shadow-teal-500/20 transition transform active:scale-95"
          >
            <Scan className="h-4 w-4" />
            <span>Launch Scanner</span>
          </button>

          <button
            onClick={() => onOpenAIAgent("Please analyze today's hospital medication administration schedule and flag any potential high-alert risks.")}
            className="flex items-center justify-center space-x-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-xl text-xs sm:text-sm font-medium transition"
          >
            <Bot className="h-4 w-4 text-teal-400" />
            <span>AI Clinical Rounds</span>
          </button>
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Active Inpatient Census (2 cols on large) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                <Users className="h-4 w-4 text-teal-400" />
                <span>Active Inpatient Roster & Bedside Status</span>
              </h3>
              <p className="text-xs text-slate-400">Click a patient to view chart, vitals, and scan prescribed medications</p>
            </div>
            <button
              onClick={() => onNavigateTab('patients')}
              className="text-xs text-teal-400 hover:text-teal-300 font-semibold flex items-center space-x-1"
            >
              <span>View All ({patients.length})</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="space-y-2.5">
            {patients.map((patient) => {
              const hasAllergy = patient.allergies.length > 0 && patient.allergies[0] !== 'No Known Drug Allergies (NKDA)';
              const isCrit = patient.condition === 'Critical';

              return (
                <div
                  key={patient.id}
                  onClick={() => onSelectPatient(patient.id)}
                  className={`p-4 rounded-xl border transition cursor-pointer hover:border-teal-500/50 ${
                    isCrit 
                      ? 'bg-rose-950/20 border-rose-800/40' 
                      : 'bg-slate-900 border-slate-800 hover:bg-slate-850'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-start space-x-3">
                      <div className={`h-10 w-10 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                        isCrit ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' : 'bg-slate-800 text-slate-300 border border-slate-700'
                      }`}>
                        {patient.room.replace('Room ', 'R')}
                      </div>

                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-bold text-white text-sm">{patient.name}</span>
                          <span className="text-xs text-slate-400 font-mono">[{patient.mrn}]</span>
                          <span className="text-xs text-slate-400">({patient.age}y {patient.gender})</span>
                        </div>

                        <p className="text-xs text-slate-300 mt-0.5">
                          <span className="text-slate-400">{patient.department}</span> • {patient.diagnosis}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2 self-end sm:self-center">
                      {hasAllergy && (
                        <span className="px-2 py-0.5 text-[11px] font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded">
                          Allergy: {patient.allergies[0]}
                        </span>
                      )}

                      <span className={`px-2 py-0.5 text-[11px] font-bold rounded ${
                        patient.condition === 'Critical' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' :
                        patient.condition === 'Observation' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' :
                        patient.condition === 'Post-Op' ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40' :
                        'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      }`}>
                        {patient.condition}
                      </span>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenScanner(patient.id);
                        }}
                        className="px-2.5 py-1 bg-teal-500/20 hover:bg-teal-500/30 text-teal-300 border border-teal-500/40 rounded-lg text-xs font-semibold flex items-center space-x-1"
                        title="Scan Medication for this patient"
                      >
                        <Scan className="h-3 w-3" />
                        <span>Scan Med</span>
                      </button>
                    </div>
                  </div>

                  {/* Vitals Ribbon */}
                  <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex flex-wrap items-center gap-4 text-xs text-slate-400 font-mono">
                    <span>BP: <strong className="text-slate-200">{patient.vitals.bp}</strong></span>
                    <span>HR: <strong className="text-slate-200">{patient.vitals.hr} bpm</strong></span>
                    <span>SpO2: <strong className={patient.vitals.spo2 < 95 ? 'text-rose-400' : 'text-slate-200'}>{patient.vitals.spo2}%</strong></span>
                    <span>Temp: <strong className="text-slate-200">{patient.vitals.temp}°C</strong></span>
                    <span className="text-slate-500 font-sans">Attending: {patient.attendingDoctor}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Department Census & Active Safety Alerts */}
        <div className="space-y-6">
          {/* Departmental Census */}
          <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
              <Activity className="h-3.5 w-3.5 text-teal-400" />
              <span>Department Occupancy Census</span>
            </h3>

            <div className="space-y-2.5">
              {departments.map((dept, i) => {
                const pct = Math.round((dept.patients / dept.capacity) * 100);
                return (
                  <div key={i} className="text-xs space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-300 font-medium">{dept.name}</span>
                      <span className="font-mono text-slate-400">{dept.patients} / {dept.capacity} beds ({pct}%)</span>
                    </div>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full ${pct > 80 ? 'bg-amber-400' : 'bg-teal-400'}`} 
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Active Safety Alerts Card */}
          <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-rose-400 flex items-center space-x-1.5">
                <ShieldAlert className="h-3.5 w-3.5 text-rose-400" />
                <span>Clinical Pharmacovigilance Alerts</span>
              </h3>
              <span className="px-1.5 py-0.5 text-[10px] font-bold bg-rose-500/20 text-rose-300 rounded">
                Live Audit
              </span>
            </div>

            <div className="space-y-2">
              <div className="p-3 bg-rose-950/40 border border-rose-800/50 rounded-lg text-xs space-y-1">
                <div className="flex items-center justify-between text-rose-300 font-bold">
                  <span>Contraindication Hold: Amoxicillin</span>
                  <span className="text-[10px] font-mono">Bed 304</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Patient Robert Vance has severe documented Penicillin allergy. Order held. Antibiotic alternative required.
                </p>
              </div>

              <div className="p-3 bg-amber-950/40 border border-amber-800/50 rounded-lg text-xs space-y-1">
                <div className="flex items-center justify-between text-amber-300 font-bold">
                  <span>Anticoagulant INR Protocol: Coumadin</span>
                  <span className="text-[10px] font-mono">Bed 412</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Eleanor Rigby scheduled for 18:00 dose. Verify morning INR lab prior to barcode administration.
                </p>
              </div>

              <div className="p-3 bg-slate-800/80 border border-slate-700 rounded-lg text-xs space-y-1">
                <div className="flex items-center justify-between text-teal-300 font-bold">
                  <span>ISMP Dual-Nurse Signoff: Regular Insulin</span>
                  <span className="text-[10px] font-mono">Bed 201</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  James Chen in ICU. Dual independent RN check required for SubQ/IV insulin titrations.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
