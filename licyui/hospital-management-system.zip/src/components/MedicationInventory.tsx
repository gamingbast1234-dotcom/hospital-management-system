import React, { useState } from 'react';
import { 
  Pill, 
  Search, 
  Plus, 
  Scan, 
  AlertTriangle, 
  CheckCircle2, 
  ShieldAlert, 
  Layers, 
  Box, 
  Clock, 
  ChevronRight,
  ExternalLink,
  Bot
} from 'lucide-react';
import { Medication } from '../types';

interface MedicationInventoryProps {
  medications: Medication[];
  onOpenScannerWithBarcode: (barcode: string) => void;
  onConsultAI: (prompt: string) => void;
  onAddMedication: (med: Medication) => void;
}

export const MedicationInventory: React.FC<MedicationInventoryProps> = ({
  medications,
  onOpenScannerWithBarcode,
  onConsultAI,
  onAddMedication,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [highAlertOnly, setHighAlertOnly] = useState(false);
  const [selectedMed, setSelectedMed] = useState<Medication | null>(null);

  const filteredMeds = medications.filter(m => {
    const matchesSearch = 
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.genericName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.barcode.includes(searchQuery) ||
      m.ndc.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || m.category === categoryFilter;
    const matchesHighAlert = !highAlertOnly || m.isHighAlert;
    return matchesSearch && matchesCategory && matchesHighAlert;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Top Title & Quick Action */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <Pill className="h-5 w-5 text-teal-400" />
            <span>Hospital Pharmacy Formulary & Inventory</span>
          </h2>
          <p className="text-xs text-slate-400">ISMP High-Alert classification, NDC barcodes, batch expiration tracking, and stock control</p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => onConsultAI("Conduct a pharmacy formulary audit on stock levels and provide reordering priorities for all high-alert medications.")}
            className="flex items-center space-x-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-750 text-teal-300 border border-slate-700 rounded-xl text-xs font-semibold"
          >
            <Bot className="h-4 w-4" />
            <span>AI Formulary Audit</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2 flex-1 min-w-[240px]">
          <Search className="h-4 w-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search drug name, generic, barcode or NDC..."
            className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-1.5 focus:outline-none focus:border-teal-400 placeholder-slate-400"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-slate-800 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-teal-400"
          >
            <option value="all">All Drug Classes</option>
            <option value="Antibiotic">Antibiotics</option>
            <option value="Anticoagulant">Anticoagulants</option>
            <option value="Cardiovascular">Cardiovascular</option>
            <option value="Analgesic">Analgesics (Opioid / Non-Opioid)</option>
            <option value="Antidiabetic">Antidiabetic</option>
            <option value="Emergency / Resuscitation">Emergency / Resuscitation</option>
          </select>

          <button
            onClick={() => setHighAlertOnly(!highAlertOnly)}
            className={`px-3 py-1.5 rounded-lg border font-semibold transition flex items-center space-x-1.5 ${
              highAlertOnly
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
            }`}
          >
            <ShieldAlert className="h-3.5 w-3.5" />
            <span>High-Alert Only</span>
          </button>
        </div>
      </div>

      {/* Formulary Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredMeds.map((med) => {
          const isLowStock = med.stockQuantity <= med.minThreshold;

          return (
            <div
              key={med.id}
              className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-teal-500/40 transition flex flex-col justify-between"
            >
              <div>
                {/* Badge Header */}
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 text-[10px] font-bold bg-slate-800 text-teal-300 border border-slate-700 rounded">
                    {med.category}
                  </span>

                  {med.isHighAlert && (
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded flex items-center space-x-1">
                      <ShieldAlert className="h-3 w-3" />
                      <span>ISMP High-Alert</span>
                    </span>
                  )}
                </div>

                {/* Drug Names & Strength */}
                <div className="mt-2.5">
                  <h3 className="font-bold text-white text-base">{med.name}</h3>
                  <p className="text-xs text-slate-400">{med.genericName}</p>
                  <p className="text-xs font-semibold text-teal-400 mt-1">
                    {med.strength} • {med.form} ({med.route})
                  </p>
                </div>

                {/* Stock Bar */}
                <div className="mt-3 p-2.5 bg-slate-800/80 rounded-lg border border-slate-750 text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Inventory Stock:</span>
                    <span className={`font-mono font-bold ${isLowStock ? 'text-rose-400' : 'text-slate-200'}`}>
                      {med.stockQuantity} {med.unit}
                    </span>
                  </div>
                  <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${isLowStock ? 'bg-rose-500' : 'bg-emerald-400'}`}
                      style={{ width: `${Math.min(100, (med.stockQuantity / (med.minThreshold * 2)) * 100)}%` }}
                    />
                  </div>
                </div>

                {/* Barcode & NDC Info */}
                <div className="mt-3 pt-2.5 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>NDC: {med.ndc}</span>
                  <span>Batch: {med.batchNumber}</span>
                </div>
              </div>

              {/* Action Button: Scan in Scanner */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center space-x-2">
                <button
                  onClick={() => onOpenScannerWithBarcode(med.barcode)}
                  className="flex-1 py-2 bg-teal-500/20 hover:bg-teal-500/30 text-teal-300 border border-teal-500/40 rounded-lg text-xs font-bold flex items-center justify-center space-x-1.5 transition"
                >
                  <Scan className="h-3.5 w-3.5" />
                  <span>Scan in BCMA Module</span>
                </button>

                <button
                  onClick={() => onConsultAI(`Explain typical adult dosages, renal considerations, and major drug interactions for ${med.name} (${med.genericName} ${med.strength}).`)}
                  className="p-2 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-lg border border-slate-700 transition"
                  title="Ask AI Pharmacologist"
                >
                  <Bot className="h-4 w-4 text-teal-400" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
