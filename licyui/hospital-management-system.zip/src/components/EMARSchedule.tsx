import React, { useState } from 'react';
import { 
  ShieldAlert, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Scan, 
  UserCheck, 
  Pill, 
  Search, 
  Filter,
  Bot
} from 'lucide-react';
import { EMAROrder, Patient, Medication } from '../types';

interface EMARScheduleProps {
  emarOrders: EMAROrder[];
  patients: Patient[];
  medications: Medication[];
  onOpenScanner: (patientId: string, barcode?: string) => void;
  onConsultAI: (prompt: string) => void;
}

export const EMARSchedule: React.FC<EMARScheduleProps> = ({
  emarOrders,
  patients,
  medications,
  onOpenScanner,
  onConsultAI,
}) => {
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredOrders = emarOrders.filter(order => {
    const patient = patients.find(p => p.id === order.patientId);
    const matchesSearch = 
      order.medicationName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (patient && patient.name.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (patient && patient.room.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <ShieldAlert className="h-5 w-5 text-teal-400" />
            <span>eMAR (Electronic Medication Administration Record)</span>
          </h2>
          <p className="text-xs text-slate-400">Scheduled clinical doses, dual-nurse verification, and five-rights barcode administration logs</p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => onConsultAI("Audit all scheduled eMAR orders for today and identify any overlapping administration times or high-alert dual-nurse sign-off requirements.")}
            className="flex items-center space-x-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-750 text-teal-300 border border-slate-700 rounded-xl text-xs font-semibold"
          >
            <Bot className="h-4 w-4" />
            <span>AI eMAR Schedule Audit</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2 flex-1 min-w-[240px]">
          <Search className="h-4 w-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search patient name, bed, or medication..."
            className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-1.5 focus:outline-none focus:border-teal-400 placeholder-slate-400"
          />
        </div>

        <div className="flex items-center space-x-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-800 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-teal-400"
          >
            <option value="all">All Order Statuses</option>
            <option value="Scheduled">Scheduled (Pending)</option>
            <option value="Administered">Administered (Completed)</option>
            <option value="Contraindicated">Contraindicated / Held</option>
          </select>
        </div>
      </div>

      {/* eMAR Timeline Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-850 text-slate-400 font-semibold border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Scheduled Time</th>
                <th className="py-3 px-4">Inpatient & Bed</th>
                <th className="py-3 px-4">Medication & Route</th>
                <th className="py-3 px-4">Dose & Frequency</th>
                <th className="py-3 px-4">Safety Status</th>
                <th className="py-3 px-4">Audit / Log Details</th>
                <th className="py-3 px-4 text-right">BCMA Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-200">
              {filteredOrders.map((order) => {
                const patient = patients.find(p => p.id === order.patientId);
                const med = medications.find(m => m.id === order.medicationId);

                return (
                  <tr key={order.id} className="hover:bg-slate-850/60 transition">
                    {/* Scheduled Time */}
                    <td className="py-3.5 px-4 font-mono font-bold text-white">
                      <div className="flex items-center space-x-1.5">
                        <Clock className="h-3.5 w-3.5 text-teal-400" />
                        <span>{order.scheduledTime}</span>
                      </div>
                    </td>

                    {/* Patient & Bed */}
                    <td className="py-3.5 px-4">
                      {patient ? (
                        <div>
                          <span className="font-bold text-white block">{patient.name}</span>
                          <span className="text-slate-400 font-mono text-[11px] block">
                            {patient.room} • {patient.bed} [{patient.mrn}]
                          </span>
                        </div>
                      ) : (
                        <span className="text-slate-400">Unassigned</span>
                      )}
                    </td>

                    {/* Medication & Route */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center space-x-2">
                        <Pill className="h-4 w-4 text-teal-400 shrink-0" />
                        <div>
                          <span className="font-bold text-white block">{order.medicationName}</span>
                          <span className="text-slate-400 text-[11px] block">{order.route}</span>
                        </div>
                      </div>
                    </td>

                    {/* Dose & Frequency */}
                    <td className="py-3.5 px-4 font-mono text-slate-300">
                      <div>{order.dosage}</div>
                      <div className="text-[11px] text-slate-400 font-sans">{order.frequency}</div>
                    </td>

                    {/* Safety Status */}
                    <td className="py-3.5 px-4">
                      {order.status === 'Administered' && (
                        <span className="inline-flex items-center space-x-1 px-2.5 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-lg font-semibold">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          <span>Administered</span>
                        </span>
                      )}
                      {order.status === 'Scheduled' && (
                        <span className="inline-flex items-center space-x-1 px-2.5 py-1 bg-teal-500/20 text-teal-300 border border-teal-500/30 rounded-lg font-semibold">
                          <Clock className="h-3.5 w-3.5" />
                          <span>Due for Scan</span>
                        </span>
                      )}
                      {order.status === 'Contraindicated' && (
                        <span className="inline-flex items-center space-x-1 px-2.5 py-1 bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded-lg font-semibold">
                          <AlertTriangle className="h-3.5 w-3.5" />
                          <span>Contraindicated / Held</span>
                        </span>
                      )}
                    </td>

                    {/* Audit Details */}
                    <td className="py-3.5 px-4 text-slate-400 text-[11px]">
                      {order.status === 'Administered' ? (
                        <div>
                          <span className="text-slate-300 font-semibold block">{order.administeredBy}</span>
                          <span>At {order.administeredAt} • Barcode Verified</span>
                        </div>
                      ) : (
                        <span className="text-slate-300 italic">{order.notes || 'Awaiting bedside barcode scan.'}</span>
                      )}
                    </td>

                    {/* Action */}
                    <td className="py-3.5 px-4 text-right">
                      {order.status === 'Scheduled' && (
                        <button
                          onClick={() => onOpenScanner(order.patientId, med?.barcode)}
                          className="px-3 py-1.5 bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-600 hover:to-emerald-700 text-white font-bold rounded-lg shadow text-xs flex items-center space-x-1.5 ml-auto"
                        >
                          <Scan className="h-3.5 w-3.5" />
                          <span>Scan & Administer</span>
                        </button>
                      )}
                      {order.status === 'Contraindicated' && (
                        <button
                          onClick={() => onConsultAI(`Explain why order ${order.medicationName} is held/contraindicated for ${patient?.name} and suggest safe clinical alternatives.`)}
                          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-750 text-rose-300 border border-rose-500/30 font-semibold rounded-lg text-xs flex items-center space-x-1 ml-auto"
                        >
                          <Bot className="h-3.5 w-3.5" />
                          <span>Review Hold with AI</span>
                        </button>
                      )}
                      {order.status === 'Administered' && (
                        <span className="text-emerald-400 font-mono text-[11px] font-semibold">
                          eMAR Signed
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
